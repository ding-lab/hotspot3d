#!/bin/perl
#2 April 2015 - Adam D Scott - 
 
use strict;
use warnings;
use Data::Dumper;
 
my $usage = 'perl search_for_variant.pl <MAF> <locations> <hs3dd> <DMKB> <clusters>
';
 
die $usage , unless @ARGV == 3;
my ( $MAF , $locations , $hs3dd , $MyCancerGenome , $clusters ) = @ARGV;
 
my %mafvariants;
my %mafcoding;
my $output = "mcg.".$clusters;
open ( CLUSTERS , "<$clusters" ) or die "Cannot open $clusters: $!";
open ( MAF , "<$MAF" ) or die "Cannot open $MAF: $!";
open ( LOCATIONS , "<$locations" ) or die "Cannot open $locations: $!";
open ( HS3DD , "<$hs3dd" ) or die "Cannot open $hs3dd: $!";
open ( MCG , "<$MyCancerGenome" ) or die "Cannot open $MyCancerGenome: $!";
open ( OUT , ">$output" ) or die "Cannot open $output: $!";

my $barcode = 16;
my $chrcol = 33;
my $startcol = 34;
my $refcol = 36;
my $varcol = 37;
my $genecol = 39;
my $transcol = 40;
my $typecol = 46;
my $cposcol = 47;
my $AAcol = 48;

while( <MAF> ) {
	chomp; if ( /Hugo/ ) { next; }
	my @line = split( "\t" , $_ );
	my $gene = $line[0];
	my $chr = $line[32];
	my $start = $line[33];
	my $stop = $line[34];
	my $ref = $line[35];
	my $var = $line[36];
	my $trv_type = $line[45];
	my $cpos = $line[46];
	my $AA = $line[47];

	if ( $trv_type =~ /del/ ) {
	} elsif ( $trv_type =~ /ins/ ) {
	}
	my $variant = join( "\t" , ( $chr , $start , $stop , $ref , $var ) );
	$cpos =~ s/c\.(.*)/$1/;
	#my $mcgvar = $cpos.$ref.">".$var;
	$mafcoding{$gene}{$cpos} = $variant;

	my $chr = $line[$chrcol-1];
	my $start = $line[$startcol-1];
	my $stop = $line[$startcol];
	my $ref = $line[$refcol-1];
	my $var = $line[$varcol-1];
	my $gene = $line[$genecol-1];
	my $trans = $line[$transcol-1];
	my $type = $line[$typecol-1];
	my $cpos = $line[$cposcol-1];
	my $AA = $line[$AAcol-1];
	if ( $type =~ /missense|in_frame/ ) {
		my $cv1 = $line[-2];
		my $cv2 = $line[-1];
		if ( $cv2 !~ /ClinVar/ ) {
			$cv1 = "NULL";
			$cv2 = "NULL";
		}

		my $vari = $chr."\t".$start."\t".$stop."\t".$ref."\t".$var;
		$mutations{$gene}{$AA}{$vari}{$trans}{$cpos} = $cv1."\t".$cv2;
		$alternates{$gene}{$vari}{$trans}{$cpos} = $AA;
	}
}
close MAF;

my %domains;
my %variants;
while( <LOCATIONS> ) {
	chomp; if ( /Gene/ ) { next; }
	my @line = split( "\t" , $_ );
	my $gene1 = $line[0];
	my $AA1 = $line[4];
	my $domain1 = $line[7];
	$domain1 = &filter_eco( $domain1 );
	my $gene2 = $line[9];
	my $AA2 = $line[13];
	my $domain2 = $line[16];
	$domain2 = &filter_eco( $domain2 );

	$domains{$gene1}{$AA1}{$domain1} = 1;
	$domains{$gene2}{$AA2}{$domain2} = 1;
}
close LOCATIONS;

my %mcg;
my %indels;
while ( <MCG> ) {
	chomp;	if ( /Gene/ ) { next; }
	my ( $gene , $cposvar , $AA , $location , $response ) = split( "\t" , $_ );
	my $cpos = $cposvar;
	if ( $AA !~ /fs/ && $cposvar !~ /dup/ && $cposvar =~ /^c\./ ) { #no frame shifts & no duplications & must start with "c."
		if ( $cpos =~ m/>/ ) { #is SNP
			$cpos =~ s/c\.(\d+)\D*/$1/;
		} else { #is indel
			$cpos =~ s/c\.(\d+\_\d+).*/$1/;
		}
		print $gene."\t".$cposvar."\t".$cpos."\t".$AA."\n";
		if ( exists $mafcoding{$gene}{$cpos} ) {
			$mcg{$gene}{$mafcoding{$gene}{$cpos}} = join( "\t" , ( $gene , $cposvar , $AA , $location , $response ) );
		}
	}
}
close MCG;

while( <HS3DD> ) {
	chomp; if ( /Gene/ ) { next; }
	my @line = split( "\t" , $_ );
	my $gene1 = $line[5];
	my $AA1 = $line[6];
	my $domain1 = $line[7];
	$domain1 = &filter_eco( $domain1 );

	$domains{$gene1}{$AA1}{$domain1} = 1;
}
close HS3DD;





my %clusters;
my %classes;
my $unclassified = "Unclassified";
my $notdrug = "NA";
my %listclasses;
open ( DRUGCLASS , "<$drugclasses" ) or die "Cannot open $drugclasses: $!";
while ( <DRUGCLASS> ) {
	chomp;
	my @line = split( "\t" , $_ );
 	if ( /Total/ ) { next; }
	##from two-column association list: drug \t class
	my $drug = $line[0];
	my $class = $line[1];
	$class =~ s/\"//g;
	$class =~ s/\;/\|/g;
	if ( $class ) {
		$classes{$drug}{$class} = 1;
	} else {
		$classes{$drug}{"Unclassified"} = 1;
	}
}
close DRUGCLASS;

 


my %families;
my %fams;
my %counted;
my $unclassified = "Unclassified";
my $notgene = "NA";
my $total = 0;
my %lines;
open ( IN , "<$families" ) or die "Cannot open $families: $!";
while ( <IN> ) {
	chomp;
	my @line = split "\t" , $_;
 
	my $gene = $line[1];
	my $family = $line[10];
	$families{$gene}{$family} = 1;
	$fams{$family} = 0;
}
close IN;




my %mutations;
my %alternates;
my %transcripts;
my %usetrans;
open ( GTL , "<$gtl" ) or die "Cannot open $gtl: $!";
while ( <GTL> )
{
	chomp;
	my @line = split( "\t" , $_ );
	my $gene = $line[0];
	my $trans = $line[1];
	my $length = $line[2];

	$transcripts{$gene}{$trans} = $length;
}
close GTL;
foreach my $gene ( keys %transcripts ) {
	my @ts = keys %{$transcripts{$gene}}; my $long = $ts[0]; $usetrans{$gene}{$long} = $transcripts{$gene}{$long};
	foreach my $trans ( keys %{$transcripts{$gene}} ) {
		if ( $usetrans{$gene}{$long} < $transcripts{$gene}{$trans} ) {
			$usetrans{$gene}{$trans} = $transcripts{$gene}{$trans};
			delete $usetrans{$gene}{$long};
			$long = $trans;
		}
	}
}



my %clusterlines;
my @c = split( "\/" , $clusters );
open ( OUT , ">$maf.$c[-1]" );
print OUT "Cluster_ID\tGene\tAAchange\tDegree\tCloseness_Centrality\tGeodesic\tFrequency\tTranscript\tc_position\tChromosome\tStart\tStop\tReference\tVariant\tClinVarAnnotation\tClinVarCitation\tLongest_Transcript\tLongest_AAchange\tLongest_c_position\n";
my %variants;
while ( <CLUSTERS> ) {
	chomp;	
	if ( /Cluster/ ) { 
		print OUT $_."\tMCG_gene\tMCG_cpos_var\tMCG_amino_acid_change\tMCG_location\tMCG_drug_response\n";
		next; 
	}
	my @line = split( "\t" , $_ );

	my $genedrug = $line[1];
	my $AAgene = $line[2];
	my $chr = $line[9];
	my $start = $line[10];
	my $stop = $line[11];
	my $ref = $line[12];
	my $var = $line[13];
	$AAgene =~ s/p\.(.*)/$1/;

	my $variant = join( "\t" , ( $chr , $start , $stop , $ref , $var ) );
	#print join( "\t" , ( $genedrug , $AAgene , $variant , $mcg{$genedrug}{$variant} ) )."\n";
	if ( exists $mcg{$genedrug}{$variant} ) {
		print join( "\t" , ( $genedrug , $variant , $mcg{$genedrug}{$variant} ) )."\n";
		print OUT join( "\t" , ( @line , $mcg{$genedrug}{$variant}."\n" ) );
	} else {
		print OUT join( "\t" , ( @line , "NULL\tNULL\tNULL\tNULL\tNULL\n" ) );
	}


	if ( exists $mutations{$gene}{$AA} ) {
		my $others = "";
		my $val = "";
		foreach my $vari ( keys %{$mutations{$gene}{$AA}} ) {
			my @l = keys %{$usetrans{$gene}}; my $long = $l[0];
			foreach my $trans ( sort keys %{$mutations{$gene}{$AA}{$vari}} ) {
				foreach my $cpos ( sort keys %{$mutations{$gene}{$AA}{$vari}{$trans}} ) {
					my @othercpos = keys %{$alternates{$gene}{$vari}{$long}}; my $othercpos = $othercpos[0];
					my $otherAA = $alternates{$gene}{$vari}{$long}{$othercpos};
					#$line[2] = $otherAA;
					$val = $mutations{$gene}{$AA}{$vari}{$trans}{$cpos};
					$clusterlines{$id}{$gene}{$AA}{$long} = join( "\t" , ( @line , $trans , $cpos , $vari , $val , $long , $otherAA , $othercpos ) );#$transcripts{$gene}{$trans} ) );
				}
			}
		}
	}


	if ( /Cluster/ ) {
		print OUT $_."\tHGNC_Gene_Families\n";
		next;
	}
	my @line = split "\t" , $_;
	
	my $id = $line[0];
	my $gene = $line[1];
	my $aachange = $line[2];
	my $mutations = $line[6];
	my @families;
	if ( $aachange =~ /p\./ ) {
		if ( exists $families{$gene} ) {
			@families = sort keys %{$families{$gene}};
			foreach my $family ( keys %{$families{$gene}} ) {
				if ( exists $fams{$family} ) {
					$fams{$family} += $mutations;
				} else {
					$fams{$family} = $mutations;
				}
			}
		} else {
			@families = ( $unclassified );
			if ( exists $fams{$unclassified} ) {
				$fams{$unclassified} += $mutations;
			} else {
				$fams{$unclassified} = $mutations;
			}
		}
		if ( not exists $counted{$gene} ) {
			$total++;
		}
	} else { 
		@families = ( $notgene );
	}
	print OUT join( "\t" , ( @line , join( "|" , @families ) ) )."\n";



 	my $id = $line[0];
 	my $drug = $line[1];
	my $gene = $line[1];
	my $AA = $line[2];
	if ( exists $classes{$drug} ) {
		my @class = sort keys %{$classes{$drug}};
		$clusters{$id}{$drug} = join( "\t" , ( @line , join( "|" , @class ) ) );
	} else {
		if ( $AA =~ /p\./ ) {
			$clusters{$id}{$gene.$AA} = join( "\t" , ( @line , $notdrug ) );
		} else {
			$clusters{$id}{$gene.$AA} = join( "\t" , ( @line , $unclassified ) );
		}
	}



	if ( /Cluster/ ) { 
		print OUT $_."\tProtein_Domain\n";
		next; 
	}
	my @line = split( "\t" , $_ );
	my $genedrug = $line[1];
	my $AAgene = $line[2];

	if ( exists $domains{$genedrug} ) {
		my @domains = keys %{$domains{$genedrug}{$AAgene}};
		print OUT join( "\t" , ( @line , join( "|" , sort @domains ) ) )."\n";
	} else {
		print OUT join( "\t" , @line )."\tNULL\n";
	}
}
close CLUSTERS;


foreach my $id ( keys %clusterlines ) {
	foreach my $gene ( sort keys %{$clusterlines{$id}} ) {
		foreach my $AA ( sort keys %{$clusterlines{$id}{$gene}} ) {
			foreach my $trans ( sort keys %{$usetrans{$gene}} ) {
				print OUT $clusterlines{$id}{$gene}{$AA}{$trans}."\n";
			}
		}
	}
}
close OUT;


print "Gene_Family\tMutations\tPercentage\n";
foreach my $family ( keys %fams ) {
	my $n = $fams{$family};
	if ( $n > 0 ) {
		my $percent = 100*$n/$total;
		print $family."\t".$n."\t";
		printf "%.3f\n" , $percent;
	}
}



foreach my $id ( keys %clusters ) {
	foreach my $spec ( keys %{$clusters{$id}} ) {
		print OUT $clusters{$id}{$spec}."\n";
	}
}




sub filter_eco {
	my ( $domain ) = @_;

	$domain =~ s/ {ECO.*//;
	$domain =~ s/^{ECO.*//;
	if ( length( $domain ) == 0 || $domain =~ /N\/A/ ) {
		$domain = "NULL";
	}

	return $domain;
}

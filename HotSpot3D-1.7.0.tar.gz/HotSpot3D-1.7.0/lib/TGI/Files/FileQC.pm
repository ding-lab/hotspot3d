package TGI::Files::FileQC;
#
#----------------------------------
# $Authors: Adam Scott
# $Date: 2017-02-22
# $Revision: v0.0 $
# $URL: $
# $Doc: $ file quality checks
# 
#----------------------------------
#
use strict;
use warnings;

use Carp;
use Scalar::Util qw( openhandle );
use List::MoreUtils qw( first_index );

use TGI::Files::File;
our @ISA = qw( TGI::Files::File );
use TGI::Data::StringTemplate;

sub new {
    my $class = shift;
    my $this = $class->SUPER::new( shift );
    $this->{'newFile'} = new TGI::Files::File( shift );
    bless $this, $class;
    return $this;
}

sub checkLines {
	my $this = shift;
	print STDOUT "\nChecking lines of ".$this->{'file_name'}." as compared to lines of ".$this->{'newFile'}->{'file_name'}.".\n";

	$this->open();

	$this->{'newFile'}->open();

	my @lines = $this->getlines( );
	my @newLines = $this->{'newFile'}->getlines( );

	my $nLines = scalar @lines;
	my $nNewLines = scalar @newLines;

	my $diff = $nLines - $nNewLines;
	if ( $nLines != $nNewLines ) {
		print STDERR "HotSpot3D::FileQC::checkLines warning: line counts do not match between ".$this->{'file_name'}." and ".$this->{'newFile'}->{'file_name'}.".\n";
	}

	return $diff;
}

sub checkColumnGrowth {
	my $this = shift;
	print STDOUT "\nChecking lines of ".$this->{'file_name'}." as compared to lines of ".$this->{'newFile'}->{'file_name'}.".\n";

	$this->open();
	$this->{'newFile'}->open();

	my $nColumns = 0;
	my @lines = $this->getlines();
	my $nLines = scalar @lines;
	foreach my $line ( @lines ) {
		chomp( $line );
		my @line = split( /\t/ , $line );
		$nColumns += scalar @line;
	}
	my $avgNColumns;
	if ( $nLines == 0 ) {
		$avgNColumns = $nColumns;
	} else {
 		$avgNColumns= $nColumns / $nLines;
	}

	my $nNewColumns = 0;
	@lines = $this->{'newFile'}->getlines();
	my $nNewLines = scalar @lines;
	foreach my $line ( @lines ) {
		chomp( $line );
		my @line = split( /\t/ , $line );
		$nNewColumns += scalar @line;
	}
	my $avgNNewColumns;
	if ( $nNewLines == 0 ) {
		$avgNNewColumns = 0;
	} else {
		$avgNNewColumns = $nNewColumns / $nNewLines;
	}

	my $diff = $nNewColumns - $nColumns;
	if ( $diff < 0 ) {
		print STDERR "HotSpot3D::FileQC::checkColumns warning: column counts do not match between ".$this->{'file_name'}." and ".$this->{'newFile'}->{'file_name'}.".\n";
	}

	return $diff;
}

sub close {
	my $this = shift;
	$this->close();
	$this->{'newFile'}->close();
	return;
}
1;

library(shiny)
ui <- basicPage(
      plotOutput("plot1",click = "plot_click", hover = "plot_hover", brush = "plot_brush" ,  height = 900),
      verbatimTextOutput("info")
    )
y = read.table("./RD.10.4.Shortest.3D_Proximity.pairwise")

    z = read.table("./RD.10.4.Shortest.3D_Proximity.pairwise.clusters.plot")
RD<-y[[2]]
ID<-y[[1]]
x0<-z[[1]]
y0<-z[[3]]
x1<-z[[2]]+1
y1<-z[[3]]
Cluster<-z[[5]]
server <- function(input, output) {
  output$plot1 <- renderPlot({
   barplot(RD,names.arg=ID,main="Reachability Plot:Epsilon=8 MinPts=4",col="Red", cex.names=0.6,border=NA, space=0, las=2, ylab="Reachabilty Distance (A)")
    segments (x0,y0,x1,y1)

        text(x1+2,y0,Cluster, cex=1)

      })
  output$info <- renderText({

        RDID_str <- function(e) {

          if (is.null(e$x)) return("")

          name <- ID[round(e$x+1)]

          RDval <- RD[round(e$x+1)]

          paste0("ID=", name, "  RD=", RDval)

        }

        RDID_range_str <- function(e) {

          if(is.null(e)) return("NULL\n")

          selrange <- ID[c(round(e$xmin+1):round(e$xmax+1))]

          paste0(selrange)

        }

        paste0(

          "   hover:", RDID_str(input$plot_hover),

          "\n", RDID_range_str(input$plot_brush)

        )

      })

    }
shinyApp(ui, server)
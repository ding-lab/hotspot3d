#!/bin/bash
# Author: Adam D Scott (adamscott@wustl.edu)
# Wrapper for all Preprocessing steps of HotSpot3D.

function run {
	dataDir=$1
	pdbDir=$2
	prefix=$4
	blat=$5
	p=$6
	d=$7
	l=$8

	if [ -z $3 ]; then
		maf=$3
		echo "hotspot3d uppro --gene-file ${maf} --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
		hotspot3d uppro --gene-file ${maf} --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err
	else
		echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
		hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err
	fi

	echo "hotspot3d calroi --output-dir ${dataDir} 1> ${prefix}.calroi.out 2> ${prefix}.calroi.err"
	hotspot3d calroi --output-dir ${dataDir} 1> ${prefix}.calroi.out 2> ${prefix}.calroi.err

	echo "hotspot3d statis --output-dir ${dataDir} 1> ${prefix}.statis.out 2> ${prefix}.statis.err"
	hotspot3d statis --output-dir ${dataDir} 1> ${prefix}.statis.out 2> ${prefix}.statis.err

	echo "hotspot3d anno --output-dir ${dataDir} 1> ${prefix}.anno.out 2> ${prefix}.anno.err"
	hotspot3d anno --output-dir ${dataDir} 1> ${prefix}.anno.out 2> ${prefix}.anno.err

	echo "hotspot3d trans --output-dir ${dataDir} --blat ${blat} 1> ${prefix}.trans.out 2> ${prefix}.trans.err"
	hotspot3d trans --output-dir ${dataDir} --blat ${blat} 1> ${prefix}.trans.out 2> ${prefix}.trans.err

	echo "hotspot3d cosmic --output-dir ${dataDir} 1> ${prefix}.cosmic.out 2> ${prefix}.cosmic.err"
	hotspot3d cosmic --output-dir ${dataDir} 1> ${prefix}.cosmic.out 2> ${prefix}.cosmic.err

	echo "hotspot3d prior --output-dir ${dataDir} --p-value-cutoff ${p} --3d-distance-cutoff ${d} --linear-cutoff ${l} 1> ${prefix}.prior.out 2> ${prefix}.prior.err"
	hotspot3d prior --output-dir ${dataDir} --p-value-cutoff ${p} --3d-distance-cutoff ${d} --linear-cutoff ${l} 1> ${prefix}.prior.out 2> ${prefix}.prior.err
}

if [ ! -z $1 ]; then
	if [ ! -z $2 ]; then
		if [ ! -z $3 ]; then
			run $1 $2 $3
		else
			run $1 $2
		fi
	else
		run $1 ${defaultDir} ${defaultOut}
	fi
else
	echo "bash $0 <maf-file> /preprocessing-dir/ \"output-prefix\""
fi

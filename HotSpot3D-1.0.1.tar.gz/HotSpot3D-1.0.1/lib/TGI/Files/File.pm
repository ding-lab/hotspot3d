package TGI::Files::File;
#
#----------------------------------
# $Authors: Adam Scott
# $Date: 2016-10-26
# $Revision: v0.0 $
# $URL: $
# $Doc: $ file handling for .mafs
# 
#----------------------------------
#
use strict;
use warnings;

use IO::File;
use FileHandle;
use Scalar::Util qw( openhandle );

sub new {
	my $proto = shift;
    my $class = ref( $proto ) || $proto;
    my $this = {};
	$this->{'handle'} = new FileHandle;
	$this->{'file_name'} = undef;
	$this->{'header'} = {};
	$this->{'required'} = undef;#\@REQUIRED;
	$this->{'required_indices'} = undef;#\@REQUIREDINDICES;
	if ( @_ ) { $this->{'file_name'} = shift; }
    bless $this, $class;
    return $this;
}

sub mapColumns {
	my $this = shift;
	my ( $required , $exception );
	$this->open();
	seek( $this->{'handle'} , 0 , 0 );
	my $headline = $this->getline();
	$this->setHeader( $headline );
	if ( @_ ) { $required = shift; } else { die "No required columns provided\n"; }
	if ( @_ ) { $exception = shift; } else { $exception = ""; }
	my $mafcols;
	my $mafi = 0;
	my %mafcols = map{ ( $_ , $mafi++ ) } split( /\t/ , $headline );
	foreach my $needColumn ( @{$required} ) {
		unless( defined( $mafcols{$needColumn} ) ) { die $exception."\n"; }
		push @{$mafcols} , $mafcols{$needColumn};
	}
	return $mafcols;
}

sub isOpen {
	my $this = shift;
	if ( defined openhandle( $this->{'handle'} ) ) {
		return 1;
	}
	return 0;
}

sub open {
    my $this = shift;
	my $hasHeader = 0;
	if ( @_ ) {
		$hasHeader = shift;
	}
    if ( defined $this->{'file_name'} ) {
		if ( not $this->isOpen() ) {
			$this->{'handle'}->open( $this->{'file_name'} , "r" );
		} else {
			seek( $this->{'handle'} , 0 , 0 );
		}
		if ( not $this->{'header'} ) {
			$this->setHeader();
		}
        return 1;
    }
    return 0;
}

sub close {
    my $this = shift;
	if ( $this->isOpen() ) {
		$this->{'handle'}->close();
	}
    return;
}

sub getlines {
    my $this = shift;
	$this->open();
	return $this->{'handle'}->getlines;
}

sub getline {
	my $this = shift;
	$this->open();
	return $this->{'handle'}->getline;
}

sub setHeader {
    my $this = shift;
	my $closed = 0;
    if ( $this->isOpen() ) { seek( $this->{'handle'} , 0 , 0 );
    } else {
		$closed = 1;
		$this->open();
	}
    my $i = 0;
    foreach my $column ( split( /\t/ , $this->getline() ) ) {
        $this->{'header'}->{$column} = $i++;
    }
	if ( $closed ) {
		$this->close();
	}
    return;
}

sub getHeader {
	my $this = shift;
	my @header;
	my %header;
	foreach my $key ( keys %{$this->{'header'}} ) {
		my $index = $this->{'header'}->{$key};
		$header{$index} = $key;
	}
	foreach my $index ( sort { $a <=> $b } keys %header ) {
		push @header , $header{$index};
	}

	return \@header;
}

sub setColumnIndex {
    my $this = shift;
    my $columnHead = shift;
    my $index = shift;
    $this->{'header'}->{$columnHead} = $index;
    return;
}

sub getColumnIndex {
    my $this = shift;
    my $columnHead = shift;
    if ( exists $this->{'header'}->{$columnHead} ) {
        return $this->{'header'}->{$columnHead};
    }
    return;
}

sub getField {
	my $this = shift;
	my $column = shift;
	my $line = shift;
	if ( $this->{'header'} eq $column ) {
        return $line->{$this->getColumnIndex( $column )};
    }
    return undef;
}

sub setCustomColumn {
    my $this = shift;
    if ( @_ ) {
        my $column = shift;
        $this->{$column} = undef;
        if ( @_ ) {
            $this->setHeaderIndex( $this->{$column} , shift );
        } else {
            $this->setHeaderIndex( $this->{$column} , -1 );
        }
    }
    return;
}

sub requireColumn {
    my $this = shift;
    if ( @_ ) {
        my $column = shift;
        my @column = ( $column );
        $this->requireColumns( \@column );
    } else {
        warn "TGI::Files::MAF::requireColumn warning: Tried to require a column, but no column name was given\n";
    }
    return $this->{'required'};
}

sub requireColumnIndex {
    my $this = shift;
    if ( @_ ) {
        my $index = shift;
        push @{$this->{'required_indices'}} , $this->{$index};
    } else {
        warn "TGI::Files::MAF::requireColumn warning: Tried to require a column, but no column name was given\n";
    }
    return $this->{'required'};
}

sub requireColumns {
    my $this = shift;
    if ( @_ ) {
        my $columns = shift;
        foreach my $column ( @{$columns} ) {
            my $found = first_index{ $column eq $_ } @{$this->{'header'}};
            if ( $found == -1 ) {
                warn "TGI::Files::MAF::requireColumns warning: a column needed to be required is not in the header (".$column.")\n";
            } else {
                $this->requireColumn( $column );
                $this->requireColumnIndex( $found );
            }
        }
    }
    return;
}

sub setColumnIndices {
    my $this = shift;
    my $exception = "";
    $this->setHeader();
    my $header = $this->getHeader();
    my $mafcols = ();
    if ( $this->{'required'} ) {
        $exception = "TGI::Files::MAF error: required columns not present ";
        $exception .= "in this .maf (".$this->{'file_name'}."). Need the ";
        $exception .= "following columns:\n\t";
        $exception .= join( "\n\t" , @{$this->{'required'}} )."\n";
        $mafcols = $this->mapColumns( $this->{'required'} , $exception );
    } else {
        $mafcols = $this->requireColumns( $this->{'required'} );
    }
    return $mafcols;
}

sub read {
    my $this = shift;
    my $keyTemplate = new TGI::Data::StringTemplate();
    my $valueTemplate = new TGI::Data::StringTemplate();
    my $haveKey = 0;
    my $haveValue = 0;
    if ( @_ ) {
        my $temp = shift;
        $keyTemplate->addToTemplate( $temp );
        $haveKey = 1;
    }
    if ( @_ ) {
        my $temp = shift;
        $valueTemplate->addToTemplate( $temp );
        $haveValue = 1;
    }
    print STDOUT "\nReading in ".$this->{'file_name'}."...\n";
    seek( $this->{'handle'} , 0 , 0 );
    my $indices = $this->setColumnIndices();
    my %output;
    my @output;
    print "Have key= ";
    if ( $haveKey ) {
        print "yes\nHave value= ";
        if ( $haveValue ) {
            print "yes\n";
            map {
                chomp;
                next if ( exists $this->{'header'}->{$_} );
                my @line = split /\t/;
                my $key = "";
                my $value = "";
                $key = $keyTemplate->constructFromColumns( \@line , $this->{'required'} );
                $value = $valueTemplate->constructFromColumns( \@line , $this->{'required'} );
                print $key." => ".$value."\n";
                $output{$key} = $value;
            } $this->getlines();
        } else {
            print "no\n";
            map {
                chomp;
                next if ( exists $this->{'header'}->{$_} );
                my @line = split /\t/;
                my $key = "";
                $key = $keyTemplate->constructFromColumns( \@line , $this->{'required'} );
                $output{$key} += 1;
                print $key." => ".$output{$key}."\n";
            } $this->getlines();
        }
        return \%output;
    } else {
        print "no\n";
        my @output = $this->getlines();
        print join( "\t" , @output )."\n";
        return \@output;
    }
    return;
}


1;

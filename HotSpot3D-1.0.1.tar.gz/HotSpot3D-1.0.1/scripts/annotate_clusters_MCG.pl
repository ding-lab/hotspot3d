#!/bin/perl
#2 April 2015 - Adam D Scott - 
 
use strict;
use warnings;
use Data::Dumper;
 
my $usage = 'perl search_for_variant.pl <MAF> <MyCancerGenome> <clusters>
';
 
die $usage , unless @ARGV == 3;
my ( $MAF , $MyCancerGenome , $clusters ) = @ARGV;
 
my %mafvariants;
my %mafcoding;
my $output = "mcg.".$clusters;
open ( MAF , "<$MAF" ) or die "Cannot open $MAF: $!";
open ( MCG , "<$MyCancerGenome" ) or die "Cannot open $MyCancerGenome: $!";
open ( OUT , ">$output" ) or die "Cannot open $output: $!";
open ( CLUSTERS , "<$clusters" ) or die "Cannot open $clusters: $!";
while( <MAF> ) {
	chomp; if ( /Hugo/ ) { next; }
	my @line = split( "\t" , $_ );
	my $gene = $line[0];
	my $chr = $line[32];
	my $start = $line[33];
	my $stop = $line[34];
	my $ref = $line[35];
	my $var = $line[36];
	my $trv_type = $line[45];
	my $cpos = $line[46];
	my $AA = $line[47];

	if ( $trv_type =~ /del/ ) {
	} elsif ( $trv_type =~ /ins/ ) {
	}
	my $variant = join( "\t" , ( $chr , $start , $stop , $ref , $var ) );
	$cpos =~ s/c\.(.*)/$1/;
	#my $mcgvar = $cpos.$ref.">".$var;
	$mafcoding{$gene}{$cpos} = $variant;
}
close MAF;

my %mcg;
my %indels;
while ( <MCG> ) {
	chomp;	if ( /Gene/ ) { next; }
	my ( $gene , $cposvar , $AA , $location , $response ) = split( "\t" , $_ );
	my $cpos = $cposvar;
	if ( $AA !~ /fs/ && $cposvar !~ /dup/ && $cposvar =~ /^c\./ ) { #no frame shifts & no duplications & must start with "c."
		if ( $cpos =~ m/>/ ) { #is SNP
			$cpos =~ s/c\.(\d+)\D*/$1/;
		} else { #is indel
			$cpos =~ s/c\.(\d+\_\d+).*/$1/;
		}
		print $gene."\t".$cposvar."\t".$cpos."\t".$AA."\n";
		if ( exists $mafcoding{$gene}{$cpos} ) {
			$mcg{$gene}{$mafcoding{$gene}{$cpos}} = join( "\t" , ( $gene , $cposvar , $AA , $location , $response ) );
		}
	}
}
close MCG;

my %variants;
#my @clu = split( "\/" , $clusters );
#my $output = "mcg".$clu[-1];
while ( <CLUSTERS> ) {
	chomp;	
	if ( /Cluster/ ) { 
		print OUT $_."\tMCG_gene\tMCG_cpos_var\tMCG_amino_acid_change\tMCG_location\tMCG_drug_response\n";
		next; 
	}
	my @line = split( "\t" , $_ );

	my $genedrug = $line[1];
	my $AAgene = $line[2];
	my $chr = $line[9];
	my $start = $line[10];
	my $stop = $line[11];
	my $ref = $line[12];
	my $var = $line[13];
	$AAgene =~ s/p\.(.*)/$1/;

	my $variant = join( "\t" , ( $chr , $start , $stop , $ref , $var ) );
	#print join( "\t" , ( $genedrug , $AAgene , $variant , $mcg{$genedrug}{$variant} ) )."\n";
	if ( exists $mcg{$genedrug}{$variant} ) {
		print join( "\t" , ( $genedrug , $variant , $mcg{$genedrug}{$variant} ) )."\n";
		print OUT join( "\t" , ( @line , $mcg{$genedrug}{$variant}."\n" ) );
	} else {
		print OUT join( "\t" , ( @line , "NULL\tNULL\tNULL\tNULL\tNULL\n" ) );
	}
}
close CLUSTERS;
close OUT;

print Dumper \%mcg;

#!/usr/bin/python

"""
Return a list of co-clustering variants
Usage: ./get_co-clusters.py [maf-ish file used as HotSpot3D input] [clusters file output from HotSpot3D] [output file name] [path to ExAC By Chromosome]
"""

import sys
if len(sys.argv) != 5:
	sys.exit(__doc__)

maf=open(sys.argv[1], "r")
clusters=open(sys.argv[2], "r")
output=open(sys.argv[3], "w")
exacbychromosome= sys.argv[4]

#First, read in MAF file and create a dictionary of variants for both ClinVar and ExAC
exac_dictionary = {}
clinvar_dictionary = {}
mafishHead = ""
for line in maf:
	if line.startswith("Hugo_Symbol"): #skip the first line
		mafishHead = line.strip().split()
		continue
	else:
		line = line.strip().split()
		if line[8]=="ExAC_r0_3_1":
			exac_dictionary[line[0]+":"+line[12]] = line
		elif line[8]=="ClinVar":
			clinvar_dictionary[line[0]+":"+line[12]] = line
		else:
			sys.exit("Something not ExAC or ClinVar is in the MAF.")
maf.close()

#Create a dictionary of clusters containing related mutation information
cluster_dictionary = {}
clinnull = '\t'.join( ["NULL" for x in range(17)] )
exacnull = '\t'.join( ["NULL" for x in range(15)] )
for line in clusters:
	if line.startswith("Cluster"):
		clinPart = [ "ClinVar_" + s for s in mafishHead ]
		exacPart = [ "ExAC_r0_3_1_" + s for s in mafishHead ]
		output.write( line.strip() + "\t" + '\t'.join( clinPart ) + "\tCLNSIG\tCLNREVSTAT\tCLNDB\t" + '\t'.join( exacPart ) + "\tALLELE_FREQUENCY\n" )
		continue
	else:
		line = line.strip().split()
		mutation = str( line[1] ) + ":" + str( line[2] )
		fields = line
		if mutation in clinvar_dictionary:
			clinstuff = clinvar_dictionary[mutation][-1].split( ";" )
			clnsig = clinstuff[0].split( "=" ) 
			clnrevstat = clinstuff[1].split( "=" ) 
			clndbn = clinstuff[2].split( "=" ) 
			fields.append( '\t'.join( str( x ) for x in clinvar_dictionary[mutation][0:14] ) + "\t" + str( clnsig[1] ) + "\t" + str( clnrevstat[1] ) + "\t" + str( clndbn[1] ) )
		else:
			fields.append( clinnull )
		if mutation in exac_dictionary:
			freq = 0
			exacstuff = exac_dictionary[mutation][13].split( "|" )
			chromosome = exacstuff[0]
			fch = open( exacbychromosome + "chr" + chromosome + ".ExAC.r0.3.1.structural.tsv" , "r" )
			for line in fch:
				chrFields = line.strip().split()
				if chrFields[1] == exacstuff[1] and \
					chrFields[2] == exacstuff[2] and \
					chrFields[3] == exacstuff[3] and \
					chrFields[4] == exacstuff[4]:
					freq = chrFields[5]
					break
			fields.append( '\t'.join( str( x ) for x in exac_dictionary[mutation][0:14] ) + "\t" + str( freq ) )
			fch.close()
		else:
			fields.append( exacnull )
		output.write( '\t'.join( str( x ) for x in fields ) + "\n" )
output.close()
#CLNSIG=5;CLNREVSTAT=no_criteria;CLNDBN=Diabetes_insipidus\x2c_nephrogenic\x2c_autosomal_recessive;CLNHGVS=NC_000012.11:g.50347951C>T;CLINVAR_VCF_ALT=T;CLNALLE=1;RV=No_RV;CSQ=T|missense_variant|MODERATE|AQP2|ENSG00000167580|Transcript|ENST00000199280|protein_coding|2/4||ENST00000199280.3:c.374G>T|ENSP00000199280.3:p.Thr125Met|459/4174|374/816|125/271|T/M|aCg/aTg|rs104894333&CM980100||1|SNV|HGNC|634|YES||CCDS8792.1|ENSP00000199280|AQP2_HUMAN||UPI000000D9DF|NM_000486.5|deleterious(0.04)|probably_damaging(0.965)|Transmembrane_helices:TMhelix&hmmpanther:PTHR19139:SF45&hmmpanther:PTHR19139&Pfam_domain:PF00230&Gene3D:1.20.1080.10&TIGRFAM_domain:TIGR00861&Superfamily_domains:SSF81338||T:0.0002|T:0.0008|T:0||T:0|T:0|T:0|||pathogenic|||||||	12|50347951|50347951|C|T|SNP|AQP2|ENST00000551526|human|ensembl|74_37|+1|known|missense|c.374|p.T125M|0.912|pfam_MIP,superfamily_Aquaporin-like,tigrfam_MIP|pfam_MIP,superfamily_Aquaporin-like,prints_MIP,tigrfam_MIP|-|no_errors|AQP2|HGNC|ENSG00000167580


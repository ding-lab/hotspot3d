package TGI::MutationProximity::Physical::Compound;
#
#----------------------------------
# $Authors: Adam D Scott $
# $Date: 2015*10*28 $
# $Revision:  $
# $URL: $
# $Doc: $ generalized class for AminoAcids, Drugs, Ions, Water
#----------------------------------
#
use strict;
use Carp;
use TGI::MutationProximity::Physical::Atom;
use TGI::MutationProximity::Physical::Point;
# base class for amino acids, ions, small molecules, etc.
sub new {    
    my $proto = shift;
    my $class = ref($proto) || $proto;
    $self->{};
	$self->{ATOMS} = {};
	$self->{NAME} = undef;
	$self->{CENTER} = new Point();
    bless ($self, $class);
    return $self;
}

sub includeAtom {
	my ( $self , $atom ) = @_;
	$self->{ATOMS}->{$atom->{ELEMENT}} = $atom;
}

sub calculateCenter {
	my $self = shift;
	my $center = new Point();
	my $atom = new Atom();
	my $natoms = 0;
	foreach $atom ( @{$self->getAtoms()} ) {
		$center->add( $atom );
		$natoms++;
	}
	if ( $natoms > 0 ) {
		$self->{CENTER} = $center->scalarDivision( $natoms );
	} else {
		confess "Cannot calculate center of atoms in this compound, beacuse there are no atoms.";
	}
}

sub xyzOfCenter {
	my ( $self ) = shift;
	unless ( defined $self->{CENTER} ) {
		$self->calculateCenter();
	}
	return $self->{CENTER}->xyz();
}

sub getAtoms {
	my ( $self ) = @_;
	my $atom = new Atom();
	my $atoms = ();
	foreach my $element ( keys $self->{ATOMS} ) {
		$atom = $self->{ATOMS}->{$element};
		push @{$atoms} , $atom;
	}
	return $atoms;
}

sub getAtom {
	my ( $self , $specificAtom ) = @_;
	my @names = grep{ /$specificAtom/ } keys $self->{ATOMS};
	if ( @names ) {
		return $self->{ATOMS}->{$names[0]};
	}
	return undef;
}

sub xyzOfAtom {
	my ( $self , $specificAtom ) = @_;
	my $atom = new Atom();
	$atom = $self->getAtom( $specificAtom );
	if ( $atom ) {
		return $atom->xyz();
	} else {
		return undef;
	}
}

sub sameAs {
    # Input: ref to a Point object
    # Return: 1 if the point has same coordinates as this one, 0 if not
    # This was changed from == comparison to 'eq' since seemingly equivalent
    # numbers were not comparing as expected.  Does Perl store as a float?
    my ( $self , $other ) = @_;
    if ( $self->{NAME} eq $other->{NAME} ) {
        my $n1 = $n2 = $same = 0;
        foreach my $atom1 ( $self->getAtoms() ) {
            $n1++;
            $n2 = 0;
            foreach my $atom2 ( $other->getAtoms() ) {
                $n2++;
                if ( $atom1->sameAs( $atom2 ) ) {
                    $same++;
                } else {
					return 0;
				}
            }
        }
        if ( $n1 == $same && $n2 == $same ) {
            return 1;
        }
    }
    return 0;
}

sub name {
	my $self = shift;
	if ( @_ ) {
		$self->{NAME} = shift;
	}
	return $self->{NAME};
}

sub center {
	my $self = shift;
	if ( @_ ) {
		$self->{CENTER} = shift;
	}
	return $self->{CENTER};
}

return 1;  

package TGI::MutationProximity::Physical::Heterogen;
#
#----------------------------------
# $Authors: Adam D Scott $
# $Date: 2015*10*28 $
# $Revision:  $
# $URL: $
# $Doc: $ heterogens parent class for drugs, ions, water
#----------------------------------
#
use strict;
use warnings;

use Carp;
use TGI::MutationProximity::Physical::Atom;
use TGI::MutationProximity::Physical::Compound;
our @ISA = qw( Compound );
# Protein compounds in crystal structure
sub new {    
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new();
    $self->{POSITION} = undef; # Residue number in peptide chain
    bless ($self, $class);
    return $self;
}

sub position {
    # Residue number in peptide chain
    my $self = shift;
    if ( @_ ) { $self->{POSITION} = shift; }
    return $self->{POSITION};
}

sub sameAs {
	my ( $self , $other ) = @_;
	if ( $self->position() == $other->position() ) {
		$self->sameAs( $other );
	}
	return 1;
}

return 1;

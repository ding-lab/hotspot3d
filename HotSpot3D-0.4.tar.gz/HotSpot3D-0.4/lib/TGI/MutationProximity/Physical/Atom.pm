package TGI::MutationProximity::Physical::Atom;
#
#----------------------------------
# $Authors: Adam D Scott $
# $Date: 2015*10*28 $
# $Revision:  $
# $URL: $
# $Doc: $ do prioritization 
#----------------------------------
#
use strict;
use Carp;
use TGI::MutationProximity::Physical::Point;
our @ISA = qw( Point );
# Point with X, Y, Z coordinates
# Used to calculate distance between atoms in PDB structure
sub new {    
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new();
    $self->{ELEMENT} = undef;
    bless ($self, $class);
    return $self;
}

sub print {
	my $self = shift;
	print "ELEMENT = ".$self->{ELEMENT}."\n";
	$self->print();
}

sub sameAs {
	my ( $self , $other ) = @_;
	if ( $self->{ELEMENT} eq $other->{ELEMENT} ) {
		if ( $self->sameAs( $other->xyz() ) ) {
			return 1;
		}
	}
	return 0;
}

sub element {
	my $self = shift;
	if ( @_ ) {
		$self->{ELEMENT} = shift;
	}
	return $self->{ELEMENT};
}

return 1;  

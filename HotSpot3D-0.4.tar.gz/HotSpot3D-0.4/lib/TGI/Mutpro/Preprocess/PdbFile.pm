package TGI::Mutpro::Preprocess::PdbFile;
#
#----------------------------------
# $Authors: Adam D Scott
# $Date: 2016-07-14
# $Revision:  $
# $URL: $
# $Doc: $ pdb download and processing 
#----------------------------------
#
use strict;
use warnings;

use LWP::Simple;
use Carp;
use TGI::Mutpro::Preprocess::GeneProtein;
use TGI::Mutpro::Preprocess::HugoGeneMethods;
use TGI::Mutpro::Preprocess::Uniprot;
#
#	endpoint: http://rest.genenames.org/
#	methods: fetch/{symbol}{alias_symbol}{prev_symbol}{uniprot_ids}/$identifier
#
sub new {
    my ($class, $uniprotId) = @_;    
	my $this = {};
	$this->{ID} = $pdbID ,
	$this->{PAGE} = "" , 
	$this->{MAF} = "" , 
	$this->{TABLE} = "" , 
	$this->{SAVE} = 0 , 
	$this->{COMPRESS} = 1 , 
    bless $this , $class;
	$this->process();
	return $this;
}

sub uniprotId {
    my $self = shift;    
    if (@_) { $self->{ID} = shift; }
    return $self->{ID};
}

sub help_text {
	return <<HELP
Usage: hotspot3d getpdbs [options]

--maf-file			A .maf on which to run analyses

--conversion-table	A symbol (HUGO) to UniProt ID table (such as HGNC)
--hugo-column		Column of conversion-table with HUGO symbol
--uniprot-column	Column of conversion-table with UniProt ID

--compress-pdb		Boolean whether to compress .pdb files, default true
--save-pdb			Boolean whether to save .pdb files, default false

NOTE:	If no conversion-table is given, this attempts to use HGNC REST 
		service for conversions. Any .tsv flat file will work, but an HGNC 
		downloaded table should work well.
TIPS:  1) Many .pdb files take a lot of space, so please BE CAREFUL with this.
	   2) Run this script wherever you want your .pdb files.
	   3) Make sure your HGNC download includes UniProt ID and the style of gene name you work with
		  HGNC downloads can be found here: http://www.genenames.org/cgi-bin/download
HELP
}

sub process {
	my $self = shift;
	unless ( @ARGV ) { die $this->help_text(); }
	$options = GetOptions( 
		'maf-file=s'			=> \$this->{MAF} ,
		'conversion-table=s'	=> \$this->{TABLE} ,
		'hugo-column=i'			=> \$this->{HUGOCOLUMN} ,
		'uniprot-column=i'		=> \$this->{UNIPROTCOLUMN} ,
		'compress-pdb=i'		=> \$this->{COMPRESS} ,
		'save-pdb=i'			=> \$this->{SAVE} ,
	);
	my $converter = TGI::Mutpro::Preprocess::GeneProtein::new();
	if ( not defined $self->{GENECOLUMN} ) {
		$self->{GENECOLUMN} = 0;
		print STDERR "HotSpot3DWarning: gene column not provided for HGNC file. Assuming it is column 0 (0-base).\n";
	}
	if ( not defined $self->{PROTEINCOLUMN} ) {
		$self->{PROTEINCOLUMN} = 1;
		print STDERR "HotSpot3DWarning: uniprot column not provided for HGNC file. Assuming it is column 1 (0-base).\n";
	}
	if ( not defined $self->{SAVE} ) {
		$self->{SAVE} = 0;
		print STDERR "HotSpot3DWarning: write PDB status not provided. Assuming not to write.\n";
	}
	if ( not defined $self->{COMPRESS} ) {
		$self->{COMPRESS} = 1;
		print STDERR "HotSpot3DWarning: compress PDB status not provided. Assuming to compress.\n";
	}


my $OUT = FileHandle->new( "$self->{OUTPUT}" , "w" );
if ( not defined $OUT ) { die "HotSpot3DError: Could not open/write $self->{OUTPUT}\n"; }

sub readMAF {
	my $self = shift;
	my $maf = shift;
	my $IN1 = FileHandle->new( $maf , "r" );
	if ( not defined $IN1 ) { die "HotSpot3DError: Could not open/read $maf\n"; }
	while ( my $line = <$IN1> ) {
		chomp( $line );
		my $gene = ( split( "\t" , $line ) )[0];
		if ( grep { $_ eq $gene } @{$self->{GENES}} ) {
			push @{$self->{GENES}} , $gene;
		}
	}
	$IN1->close();
}

sub readConversion {
	my $self = shift;
	if ( not $self->conversion() ) {
	my $table = shift;
my %map;
my $IN2 = FileHandle->new( "$self->{CONVERSION}" , "r" );
if ( not defined $IN2 ) { die "HotSpot3DError: Could not open/write $self->{CONVERSION}\n"; }
while ( my $line = <$IN2> ) {
	chomp( $line );
	my ( $hugo , $uniprot ) = (split( "\t" , $line ))[$self->{GENECOLUMN},$self->{PROTEINCOLUMN}];
	if ( grep{ $_ eq $hugo } @genes ) {
		$map{$hugo} = $uniprot;
	}
}
$IN2->close();

my $uniprotBase = "http://www.uniprot.org/uniprot/";
$OUT->print( "Gene\tUniProt\tPDB_ID\tMethod\tResolution\tChain_Start\tChain_End\tChains\n" );
my ( $pdbURL , $pdbPage , $PDB );
my $pdbBase = "http://www.rcsb.org/pdb/files/";
foreach my $hugo ( keys %map ) {
	my ( $url , $page , $pdb , $method , $resolution , $positions , $chains , $residues , $begin , $end );
	my $uniprot = $map{$hugo};
	print STDOUT $hugo."\t";
	if ( defined $uniprot ) {
		$url = $uniprotBase.$uniprot.".txt";
		print STDOUT $url."\t";
		$page = get( $url );
		if ( $page ) {
			print STDOUT "success\t";
			foreach my $line ( split( "\n" , $page ) ) {
				if ( $line =~ m/^DR/ ) {
					if ( $line =~ m/PDB;/ ) { #PDBsum lines also have PDB ID
						chomp( $line );
						my @line = split( /\s*;/ , $line );
						( $pdb , $method , $resolution , $positions ) = @line[1,2,3,4];
						$pdb =~ s/\s*(\w\w\w\w)/$1/;
						print STDOUT $pdb."\t";
						( $chains , $residues ) = split( "=" , $positions );
						if ( $residues =~ /-/ ) {
							( $begin , $end ) = split( "-" , $residues );
						} else {
							$begin = $residues;
							$end = $residues;
						}
						$end =~ s/(\d*)\./$1/;
						$OUT->print( join( "\t" , ( $hugo , $uniprot , $pdb , $method , $resolution , $begin , $end , $chains ) )."\n" );

						if ( $self->{SAVE} ) {
							$pdbURL = $pdbBase.$pdb.".pdb";
							if ( $self->{COMPRESS} ) {
								$pdbURL .= ".gz";
							} else {
								$PDB = FileHandle->new( $pdb.".pdb" , "w" );
								if ( not defined $PDB ) { die "HotSpot3DError: Could not open/write ".$pdb.".pdb\n"; }
							}
							print STDOUT $pdbURL."\t";
							$pdbPage = get( $pdbURL );
							if ( not $self->{COMPRESS} and $pdbPage ) {
								print STDOUT "writing\t";
								foreach my $line ( split( "\n" , $pdbPage ) ) {
									$PDB->print( $line."\n" );
								}
								$PDB->close();
							} else {
								print STDOUT "downloaded\t";
							}
						}
						print STDOUT "\n";
					}
				} #if uniprot line starts with DR
			} #foreach line in uniprot page
		} #if uniprot page
	} #if uniprot id
	print STDOUT "\n";
} #foreach hugo
$OUT->close();

sub entireRecord {
    # Return: entire text record stored as a mulit-line page
    # Can be parsed by doing 
    #  foreach $line (split /\n/, $page) { chomp $line; etc.. }
    my $self = shift;
    if ( $self->{PAGE} eq "" ) { $self->retrieveRecordFromUniprot(); }
    return $self->{PAGE};
}

sub retrieveRecordFromUniprot {
    # Download current record from Uniprot web site.
    my $self = shift;
    my $uniprotId = $self->uniprotId();
    my $uniProtUrl = "http://www.uniprot.org/uniprot/$uniprotId.txt";
    my $page = get($uniProtUrl);
    if ( !defined $page ) { $page = "empty"; }
    $self->{PAGE} = $page;
}

sub generalAnnotation {
    # Returns: ref to array of general comments 
    # These are in the record preceeded by 'CC' and the
    # general annotion type is given in all caps e.g.
    # CC   -!- FUNCTION: Acts as a tumor suppressor in many tumor types; induces
    # CC       growth arrest or apoptosis depending on the physiological
    # CC       etc.
    # There are about 30 possible entries, but don't know how each one is
    # formated.  These are some:
    # CC   -!- FUNCTION: Function
    # CC   -!- COFACTOR: Cofactor
    # CC   -!- SUBUNIT:  Subunit structure
    # CC   -!- SUBCELLULAR LOCATION: Subcellular location
    # CC   -!- DOMAIN:   Domain
    # CC   -!- PTM:      Post-translational modification
    # CC   -!- DISEASE:  Involvement in disease
    # CC   -!- SIMILARITY:  Sequence similarities
    # CC   -!- INTERACTION:
    my $self = shift;
    my $annotationType = shift;
    my ( @annotations, $readingType, );
    $readingType = 0;
    foreach my $line ( split /\n/, $self->entireRecord() ) {
        chomp $line;
        if ( $line =~ /CC\s+\-\!\-\s+\w+/ ) { $readingType = ( $line =~ /CC\s+\-\!\-\s+$annotationType/i ) ? 1 : 0; }
	if ( $line =~ /CC\s+Copyrighted/ ) {  $readingType = 0; last; }
	if ( $readingType ) { push @annotations, $line; }
    }
    return \@annotations;
}
    

sub annotations {
    # Returns: ref to array of annotations of given type
    # These are in the record as 'DR $annotationName; $id; $record'
    # e.g. 
    # DR   InterPro; IPR000008; C2_Ca-dep.
    # DR   Pfam; PF00168; C2; 2
    # DR   PDB; 1V27; NMR; -; A=807-934.
    # DR   UniGene; Hs.655271; -.
    # DR   GO; GO:0005783; C:endoplasmic reticulum; IEA:UniProtKB-SubCell.
    #    The GO annotation is described in detail below
    #
    my $self = shift;
    my $annotationType = shift;
    my @annotations;
    (defined $annotationType) || confess "Did not get an annotation type as input parameter";
    foreach my $line ( split /\n/, $self->entireRecord() ) { 
        chomp $line; 
        if ( $line =~ /DR\s+$annotationType\;\s+(.*)/i ) { push @annotations, $1; }
    }
    return \@annotations;
}

sub sequenceFeatures {
    # Large section that includes domains
    # It has 'FT   $Tag  $start  $stop $description'
    # Can be used to get MUTAGEN (sites that have been mutagenized) CONFLICT VAR_SEQ, etc.
    my $self = shift;
    my $tag = shift;
    (defined $tag) || carp "No tag sent to sub sequenceFeature", return undef;
    my ( $line, @features );
    @features = ();
    foreach $line ( split /\n/, $self->entireRecord() ) {
        chomp $line;
        if ( $line =~ /FT\s+$tag/ ) { push @features, $line; }
    }

    return \@features;
}

sub domains {
    # Input: start and <optional stop> for region of interest
    # Return: ref to array of domains that overlap the given region
    # Skips the following entries: CONFLICT STRAND HELIX TURN VAR_SEQ INIT_MET VARIANT CHAIN
    my $self = shift;
    my ($start, $stop) = @_;
    (defined $start) || carp "Start not defined for $self->{ID}", return undef;
    if ( !defined $stop ) { $stop = $start; }
    my ( @domains, $line, %skipList, $desc, $key, $dmStart, $dmStop );
    my @skipThese = qw (CONFLICT STRAND HELIX TURN VAR_SEQ INIT_MET VARIANT CHAIN);
    map{ $skipList{$_} = 1; } @skipThese;
    foreach $line (split /\n/, $self->entireRecord()) {
	chomp $line;
	if ($line =~ /FT\s+(\S+)\s+(\d+)\s+(\d+)\s+(.*)/ && $stop >= $2 && $start <= $3 ) { 
	    $key = $1; $dmStart = $2; $dmStop = $3; $desc = $4;
	    next if ( defined $skipList{$key} );
	    push @domains, "$key\t($dmStart, $dmStop)\t$desc";
	}elsif ($line =~ /FT\s+DISULFID\s+(\d+)\s+(\d+)/ && ( ($stop >= $1 && $start <= $1) || ($stop >= $2 && $start <= $2) )) { 
	    push @domains, "DISULFID\t($1, $1)\tDisulfide bond $1 <-> $2.";
	    push @domains, "DISULFID\t($2, $2)\tDisulfide bond $1 <-> $2.";
	}elsif ( $line =~ /FT\s+SIGNAL\s+(\d+)\s+(\d+)/ && $stop >= $2 && $start <= $1 ) { 
	    push @domains, "SIGNAL\t($1, $2)\tSignal peptide.";
	}
    }
    return \@domains;
}

sub domainsForMultiplePositions {
    # Input: ref to hash of positions in Uniprot coordinate system
    # Return: ref to array of domains that contain at least one of
    #         the positions
    # Skips the following entries: CONFLICT STRAND HELIX TURN VAR_SEQ INIT_MET VARIANT CHAIN
    my ($self, $positionRef) = @_;
    my ( $position, $addEntry, @domains, $line, %skipList, $desc, $key, $dmStart, $dmStop );
    my @skipThese = qw (CONFLICT STRAND HELIX TURN VAR_SEQ INIT_MET VARIANT CHAIN);
    map{ $skipList{$_} = 1; } @skipThese;
    foreach $line ( split /\n/, $self->entireRecord() ) {
        chomp $line;
	if ( $line =~ /FT\s+(\S+)\s+(\d+)\s+(\d+)\s+(.*)/ && !defined $skipList{$1} ) {
            $key = $1; $dmStart = $2; $dmStop = $3; $desc = $4;
	    $addEntry = 0;
	    # See if any of the positions are within this domain
	    foreach $position (keys %{$positionRef}) {
		if ( $position >= $dmStart && $position <= $dmStop ) { $addEntry = 1; }
	    }
	    if ( $addEntry ) { push @domains, "$key\t($dmStart, $dmStop)\t$desc"; }
	}
    }
    return \@domains;
}

sub domainsAfterPosition {
    # This is for nonsense mutations.
    # List all domains that occur after the given position
    # Input: amino acid start position
    # Return: ref to array of domains that are after the position
    # Skips the following entries: CONFLICT STRAND HELIX TURN VAR_SEQ INIT_MET VARIANT CHAIN
    my $self = shift;
    my $position = shift;
    (defined $position) || carp "\$position not defined for $self->{ID}", return undef;
    my ( @domains, $line, %skipList, $desc, $key, $dmStart, $dmStop );
    my @skipThese = qw (CONFLICT STRAND HELIX TURN VAR_SEQ INIT_MET VARIANT CHAIN);
    map{ $skipList{$_} = 1; } @skipThese;
    foreach $line ( split /\n/, $self->entireRecord() ) {
	chomp $line;
	if ( $line =~ /FT\s+(\S+)\s+(\d+)\s+(\d+)\s+(.*)/ && $3 > $position ) { 
	    $key = $1; $dmStart = $2; $dmStop = $3; $desc = $4;
	    next if ( defined $skipList{$key} );
	    push @domains, "$key\t($dmStart, $dmStop)\t$desc";
	}
    }
    return \@domains;
}

sub sequence {
    # Returns sequence as a string
    my $self = shift;
    my ( $line, $seq, $readingSeq, );
    $readingSeq = 0;
    $seq = "";
    my $record = $self->entireRecord();
    if ( !defined $record ) { return undef; }
    foreach  $line ( split /\n/, $self->entireRecord() ) {
	chomp $line;
	if ( $line =~ /\/\// ) { $readingSeq = 0; }
	if ( $line =~ /SQ\s+SEQUENCE/ ) { $readingSeq = 1; next; }
	if ( $readingSeq ) { $line =~ s/\s+//g; $seq .= $line; }
    }
    return $seq;
}

# Beifang Niu 05-06-2013
# added this function to get the Ensemble thranscript id
# and corresponding Protein id
#
sub transProteinHash{
    # Returns hash:
    # $hash{transcriptid} = protein id
    my $self = shift;
    my %transProtein;
    my ( $line, $seq, $readingSeq,);
    $readingSeq = 0; 
    $seq = "";
    my $record = $self->entireRecord();
    if ( !defined $record ) { return undef; }
    foreach $line ( split /\n/, $self->entireRecord()) {
	chomp $line;
	if ( $line =~ /^DR\s+Ensembl;\s+(\w+);\s+(\w+);\s+(\w+)/ ) { $transProtein{$1} = $2; }
    }
    return \%transProtein;
}

return 1;

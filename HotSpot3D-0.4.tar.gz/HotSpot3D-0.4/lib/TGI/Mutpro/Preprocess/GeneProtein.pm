package TGI::Mutpro::Preprocess::GeneProtein;
#15 July 2016 - Adam D Scott - 

use strict;
use warnings;

use IO::File;
use FileHandle;
use HTTP::Tiny;
use XML::Simple;

use Data::Dumper;

# tests for symbol, alias_symbol, and prev_symbol: ERBB2, HER2, NGL
#my $uniprot = hugo2uniprot( shift );
#my $hugo = uniprot2hugo( $uniprot );

sub new {
	my ( $class ) = @_;
	bless {
		HUGO => [] ,
		PREVIOUS => [] ,
		ALIAS => [] ,
		UNIPROT => [] ,
	} , $class;
}

sub hugo {
	my $self = shift;
	if ( @_ ) {
		push @{$self->{HUGO}} , shift;
	}
	return $self->{HUGO};
}

sub previous_alias {
	my $self = shift;
	if ( @_ ) {
		$self->{PREVIOUS} = shift;
	}
	return $self->{PREVIOUS};
}

sub alias_symbol {
	my $self = shift;
	if ( @_ ) {
		$self->{ALIAS} = shift;
	}
	return $self->{ALIAS};
}

sub uniprot_id {
	my $self = shift;
	if ( @_ ) {
		$self->{UNIPROT} = shift;
	}
	return $self->{UNIPROT};
}

## ReST
sub uniprotFromREST {
	my $self = shift;
	my $content = shift;
	$self->uniprot_id( $content->{'result'}->{'doc'}->{'arr'}->{'uniprot_ids'}->{'str'} );
	return;
}

sub symbolFromREST {
	my $self = shift;
	my $content = shift;
	foreach my $doc ( @{$content->{'result'}->{'doc'}} ) {
		$self->hugo( $doc->{'str'}->{'symbol'}->{'content'} );
	}
	return;
}

sub symbol2uniprot {
	my $self = shift;
	my $symbol = shift;
	my $http = HTTP::Tiny->new();
	my $url = "http://rest.genenames.org/fetch/symbol/".$symbol;
	print $url."\n";
	my $hgnc = $http->get( $url , { headers => { 'Accept' => 'text/xml' } } );
	#print Dumper( $hgnc->{'content'} );
	if ( $hgnc->{'status'} == '200' and checkFound( $hgnc ) ) {
		my $content = XMLin( $hgnc->{'content'} );
		$self->uniprotFromREST( $content );
		print Dumper( $self->{UNIPROT} )."\n";
	} else {
		print STDERR $hgnc->{'reason'}."\n";
		$self->alias2uniprot( $symbol );
	}
	return $self->{UNIPROT};
}

sub alias2uniprot {
	my $self = shift;
	my $symbol = shift;
	my $http = HTTP::Tiny->new();
	my $url = "http://rest.genenames.org/fetch/alias_symbol/".$symbol;
	print $url."\n";
	my $hgnc = $http->get( $url , { headers => { 'Accept' => 'text/xml' } } );
	if ( $hgnc->{'status'} == '200' and checkFound( $hgnc ) ) {
		my $content = XMLin( $hgnc->{'content'} );
		$self->uniprotFromREST( $content );
		print Dumper( $self->{UNIPROT} )."\n";
	} else {
		print STDERR $hgnc->{'reason'}."\n";
		$self->previous2uniprot( $symbol );
	}
	return $self->{UNIPROT};
}

sub previous2uniprot {
	my $self = shift;
	my $symbol = shift;
	my $http = HTTP::Tiny->new();
	my $url = "http://rest.genenames.org/fetch/prev_symbol/".$symbol;
	print $url."\n";
	my $hgnc = $http->get( $url , { headers => { 'Accept' => 'text/xml' } } );
	if ( $hgnc->{'status'} == '200' and checkFound( $hgnc ) ) {
		my $content = XMLin( $hgnc->{'content'} );
		$self->uniprotFromREST( $content );
		print Dumper( $self->{UNIPROT} )."\n";
	} else {
		print STDERR $hgnc->{'reason'}."\n";
	}
	return $self->{UNIPROT};
}

sub uniprot2hugo {
	my $self = shift;
	my $uniprotID = shift;
	my $http = HTTP::Tiny->new();
	my $url = "http://rest.genenames.org/fetch/uniprot_ids/".$uniprotID;
	print $url."\n";
	my $hgnc = $http->get( $url , { headers => { 'Accept' => 'text/xml' } } );
	#print Dumper( $hgnc );
	if ( $hgnc->{'status'} == '200' and checkFound( $hgnc ) ) {
		my $content = XMLin( $hgnc->{'content'} );
		$self->symbolFromREST( $content );
	} else {
		print $hgnc->{'reason'}."\n";
	}
	print Dumper( @{$self->{HUGO}} );
	return $self->{HUGO};
}

sub checkFound {
	my $response = shift;
	my $content = XMLin( $response->{'content'} );
	my $found = $content->{'result'}->{'numFound'};
	#print $found."\n";
	if ( $content->{'result'}->{'numFound'} > 0 ) {
		return 1;
	}
	return 0;
}

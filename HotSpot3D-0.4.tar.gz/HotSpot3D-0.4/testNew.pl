#!/usr/bin/perl
#27 July 2016 - Adam Scott - 

use strict;
use warnings;

use IO::File;
use FileHandle;

use Data::Dumper;
use TGI::Mutpro::Preprocess::HugoGeneMethods;

my @list = ( "ABL1" , "ASDFQWER" );
my $hgr = TGI::Mutpro::Preprocess::HugoGeneMethods::makeHugoGeneObjectsFromList( \@list );
print Dumper( $hgr );

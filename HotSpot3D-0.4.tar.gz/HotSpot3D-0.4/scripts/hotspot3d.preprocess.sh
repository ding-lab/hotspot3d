#!/bin/bash
# Author: Adam D Scott (adamscott@wustl.edu)
# Wrapper for all Preprocessing steps of HotSpot3D.

function run {
	maf=$1
	dataDir=$2
	prefix=$3

	pairwiseFile="${prefix}.pairwise"
	intraFile="${prefix}.pairwise.singleprotein.collapsed"
	interFile="${prefix}.pairwise.complex.collapsed"
	clustersIntraFile="${intraFile}.clusters"
	clustersInterFile="${interFile}.clusters"
	summaryIntraFile="${clustersIntraFile}.summary"
	summaryInterFile="${clustersInterFile}.summary"

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

	echo "hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err"
	hotspot3d uppro --output-dir ${dataDir} --pdb-file-dir ${pdbDir} 1> ${prefix}.uppro.out 2> ${prefix}.uppro.err

}

defaultOut="hotspot3d.results"
defaultDir="./"
if [ ! -z $1 ]; then
	if [ ! -z $2 ]; then
		if [ ! -z $3 ]; then
			run $1 $2 $3
		else
			run $1 $2 ${defaultOut}
		fi
	else
		run $1 ${defaultDir} ${defaultOut}
	fi
else
	echo "bash $0 <maf-file> /preprocessing-dir/ \"output-prefix\""
fi

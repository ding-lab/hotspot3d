#!/bin/bash

perl test_significance.pl --prep-dir /gscmnt/gc2706/dinglab/medseq/Premed/HS3D/Preprocessing_Output_20141023 --pairwise /gscmnt/gc2706/dinglab/medseq/Premed/HS3D/PancanII/HotSpot3D_100815/pancanII.pairwise --clusters /gscmnt/gc2706/dinglab/medseq/HotSpot3D/Sohini_Tests/hotspot3d/t/pancanII.05.intra.0..05.10.clusters --output pancanII.intra.0..05.10





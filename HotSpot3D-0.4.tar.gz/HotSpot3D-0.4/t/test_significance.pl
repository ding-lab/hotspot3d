
use strict;
use warnings;

use IO::File;
use FileHandle;


use Significance;#TGI::Mutpro::Main::Significance;

Significance->new();#TGI::Mutpro::Main::Significance->new();
~                                                                                                                                                                                                                                            
~                                                                                                                                                                                                                                            
~                                                            
